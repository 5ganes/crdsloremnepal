<!DOCTYPE HTML>
<html>
    <head>
        <title>Community Rural Development Society-Nepal</title>
        <meta http-equiv="content-type" content="text/html; charset=utf-8" />
        <meta name="description" content="" />
        <meta name="keywords" content="" />
        <link href='http://fonts.googleapis.com/css?family=Roboto+Condensed:700italic,400,300,700' rel='stylesheet' type='text/css'>
        <!--[if lte IE 8]><script src="js/html5shiv.js"></script><![endif]-->
        <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
        <script src="js/skel.min.js"></script>
        <script src="js/skel-panels.min.js"></script>
        <script src="js/init.js"></script>
        <noscript>
            <link rel="stylesheet" href="css/skel-noscript.css" />
            <link rel="stylesheet" href="css/style.css" />
            <link rel="stylesheet" href="css/style-desktop.css" />
        </noscript>
        <!--[if lte IE 8]><link rel="stylesheet" href="css/ie/v8.css" /><![endif]-->
        <!--[if lte IE 9]><link rel="stylesheet" href="css/ie/v9.css" /><![endif]-->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    </head>
    <body class="left-sidebar">

    <div class="top-bar"></div>
    <!-- Header -->
        <div id="header">
            <div>
            <!-- Logo -->
                <div id="logo">
                    <h1><a href="#"><img src="images/logo.png"></a></h1>
                </div>
                <div>
                    <img src="./images/flag.gif" width="5%" align="right" style="padding-top: 2% ; padding-right: 1%">
                </div>
                <div  id="title" style="text-align:Center">
                    <h1>Community Rural Development Society-Nepal</h1>
                    <h2>सामुदायिक ग्रामीण विकास समाज-नेपाल</h2>
                    <h3>(CRDS - Nepal)</h3>
                </div>
            </div>
            <br>
            <div class="container">
                <!-- Nav -->
                    <nav id="nav">
                        <ul>
                            <li class="active"><a href="index1.html">Homepage</a></li>
                            <li><a href=#>Programmes</a></li>
                            <li><a href=#>Resource Center</a></li>
                            <li><a href=#>About Us</a></li>
                            <li><a href=#>Staffs</a></li>
                            <li><a href=#>Vacancy</a></li>
                            <li><a href=#>Contact Us</a></li>
                            <div style="clear: both;"></div>
                        </ul>
                    </nav>

            </div>
        </div>
    <!-- Header -->
    <!-- /BannerPic -->
    <div class="slider-div">
        <div>
            <img src="./images/banner.jpg">
        </div>
    </div>
        <!-- /Banner -->

    <!-- slideshow 
        <div id="banner">
            <div class="container" >
            <img src="./images/banner.jpg" width="90%" style="padding-left: 15% ">
        </div>
    </div>
    <!-- slideshow-->

    <!-- Main -->
        <div id="page">
                
            <!-- Main -->
            <div id="main" class="container">
                <div class="row">

                    <div class="3u">
                        <section class="sidebar">
                            <header>
                                <h2>Side Bar1</h2>
                            </header>
                            <ul class="style1">
                                <li><a href="#">Sub Menu1</a></li>
                                <li><a href="#">Sub Menu2</a></li>
                                <li><a href="#">Sub Menu3</a></li>
                                <li><a href="#">Sub Menu4</a></li>
                                <li><a href="#">Sub Menu5</a></li>
                            </ul>
                        </section>
                        <section class="sidebar">
                            <header>
                                <h2>Notice Board</h2>
                            </header>
                            <ul class="style1">
                                <li><a href="#">Update1</a></li>
                                <li><a href="#">Update2</a></li>
                                <li><a href="#">Update3</a></li>
                                <li><a href="#">Update4</a></li>
                                <li><a href="#">Update5</a></li>
                            </ul>
                        </section>
                    </div>
                
                    <div class="6u skel-cell-important">
                        <section class="sidebar">
                            <header>
                                <h2>Introduction</h2>
                            </header>
                            <p>CRDS-Nepal is a rural development organization based in Darchula District of the FWDR region in Nepal. Since 1992 we have sought to improve the quality of life of families – with a special emphasis on women, children and the poor – residing in villages of the Rural areas. We recognize the need for an integrated approach to development and consequently our activities are diverse.</p>
                            <p>Community Rural Development Society–Nepal (CRDS-Nepal) is a non-political, non-governmental, and non-profit national organization working since 1992 in the field of community, human resource and infrastructure development, natural resource conservation utilization and income generation for livelihood improvement of the rural people through participatory and right based approaches. This organization has been working with the poorest and most downtrodden people who are typically social outcasts, women, children and disadvantaged groups consisting of different castes and races in the Far Western Region of Nepal since establishment. CRDS Nepal has partnership with many governmental and non-governmental organizations and donor agencies working in Nepal.</p>
                            <p>Thus working with variety of organizations and programs CRDS - Nepal has developed competency in different aspect of community development and livelihood improvement during last twenty two years.  Currently it is strengthening its working area to new themes guided by corporate responsibility, social business and economic and other rights of civil society to sustain it and its community development endeavours.</p>
                            <p>We constantly seek to learn from the people we work with and focus on developing strong community based institutions to ensure the sustainable management and use of natural resources in the region. We continue to learn and adapt each year. Our geographical area of operations has grown over time but we continue to remain true to our original idea of seeking to improve the quality of life of rural families and in particular the poor and women.CRDS-Nepal has been fortunate to benefit from the contribution of a diverse set of young professionals who have lived and worked here over time. However, the core and backbone of the organization is comprised of people from the region who have grown with the organization.</p>
                            <p>It is one of the pioneering NGOs that have adopted the Participatory Approach in working with poor, marginalized families and communities in delivering developmental programs in remote districts like Darchula as it was registered just after reestablishment of democracy in the country. It has consistently changed its working strategy with governmental and non-governmental sector community development policy and working policy of different donor agencies up to now. As it is nongovernmental organization closely associated with rural people and civil society organizations, it has harmonized its working strategy with them.</p>
                        </section>
                    </div>
                 
                 <div class="3u">
                        <section class="sidebar">
                            <header>
                                <h2>Side Bar2</h2>
                            </header>
                            <ul class="style1">
                                <li><a href="#">Sub Menu1</a></li>
                                <li><a href="#">Sub Menu2</a></li>
                                <li><a href="#">Sub Menu3</a></li>
                                <li><a href="#">Sub Menu4</a></li>
                                <li><a href="#">Sub Menu5</a></li>
                            </ul>
                        </section>
                    </div>   
                </div>
            </div>
            <!-- Main -->

        </div>
    <!-- /Main -->

    <!-- Featured -->
        <div id="featured">
            <div class="container">
                <div class="row">
                    <section class="4u">
                        <div class="box">
                            <a href="#" class="image left"><img src="images/pics04.jpg" alt=""></a>
                            <h3>Featured1</h3>
                            <p>Brief Information (Just a preview)</p>
                            <p>1</p>
                            <p>2</p>
                            <p>3</p>
                            <p>4</p>
                            <a href="#" class="button">More</a>
                        </div>
                    </section>
                    <section class="4u">
                        <div class="box">
                            <a href="#" class="image left">
                                <iframe src="https://www.youtube.com/embed/OJjW9N9BbLc">
                                </iframe>
                            </a>
                            <h3>Featured2</h3>
                            <p>Viedo Information (Just a preview)</p>
                            <a href="#" class="button">More</a>
                        </div>
                    </section>
                    <section class="4u">
                        <div class="box">
                            <a href="#" class="image left"><img src="images/pics06.jpg" alt=""></a>
                            <h3>Featured3</h3>
                            <p>Brief Information (Just a preview)</p>
                            <p>1</p>
                            <p>2</p>
                            <p>3</p>
                            <p>4</p>
                            <a href="#" class="button">More</a>
                        </div>
                    </section>
                </div>
                <div class="divider"></div>
            </div>
        </div>
    <!-- /Featured -->

    <!-- Footer -->
        <div id="footer">
            <div class="container">
                <div class="row">
                    <div class="5u">
                        <section>
                            <h2>Quick Link</h2>
                            <a href="#" class="button">Link1</a>
                            <a href="#" class="button">Link2</a>
                            <a href="#" class="button">Link3</a>
                            <a href="#" class="button">Link4</a>
                            <a href="#" class="button">Link5</a>
                        </section>
                    </div>
                    <div class="12u">
                    <section>
                            <h2>Suscribe</h2>
                            <a href="#" class="fa fa-facebook"></a>
                            <a href="#" class="fa fa-twitter"></a>
                            <a href="#" class="fa fa-google"></a>
                            <a href="#" class="fa fa-linkedin"></a>
                            <a href="#" class="fa fa-youtube"></a>
                            <a href="#" class="fa fa-instagram"></a>
                            <a href="#" class="fa fa-pinterest"></a>
                            <a href="#" class="fa fa-snapchat-ghost"></a>
                            <a href="#" class="fa fa-skype"></a>
                            <a href="#" class="fa fa-android"></a>
                            <a href="#" class="fa fa-dribbble"></a>
                            <a href="#" class="fa fa-vimeo"></a>
                            <a href="#" class="fa fa-tumblr"></a>
                            <a href="#" class="fa fa-vine"></a>
                            <a href="#" class="fa fa-foursquare"></a>
                            <a href="#" class="fa fa-stumbleupon"></a>
                            <a href="#" class="fa fa-flickr"></a>
                            <a href="#" class="fa fa-yahoo"></a>
                            <a href="#" class="fa fa-reddit"></a>
                            <a href="#" class="fa fa-rss"></a>
                        </section>
                        </div>
                </div>
            </div>
        </div>
    <!-- /Footer -->

    <!-- Copyright -->
        <div id="copyright" class="container">
        © 2017 Community Rural Development Society-Nepal <br>
        Copyright @Krishi Ghar 2017. All rights reserved. <br>
        </div>


    </body>
</html>