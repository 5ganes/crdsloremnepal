<ul class="menu">
	<li>
  		<p>Admin Site</p>
  		<ul>
    		<li><a href="index.php">Home</a></li>
      		<li><a href="changepswd.php">Change Password</a></li>
      		<li><a href="logout.php">Logout</a></li>
    	</ul>
  	</li>
  	<li>
  		<p>Manage Info</p>
    	<ul>
            <li><a href="cms.php">Manage Contents</a></li>
            <li><a href="cms.php?groupType=Header">Manage Menubar</a></li>
            <li><a href="cms.php?groupType=Navigation">Manage Navigation</a></li>
            <li><a href="cms.php?id=723&parentId=0&groupType=Other">Manage Slider</a></li>
            <li>
              <a href="cms.php?parentId=845&groupType=Other&open">Important Links</a>
            </li>
            <li><a href="cms.php?id=176&parentId=0&groupType=Other">Welcome Message</a></li>
            <li><a href="cms.php?id=274&parentId=0&groupType=Other">Message From Chief</a></li>
            <li><a href="cms.php?id=858&parentId=0&groupType=Other&groupType=Other&open">Footer Gallery</a></li>
            <li><a href="cms.php?id=867&parentId=0&groupType=Other">Footer Video</a></li>
            <!-- <li><a href="manageuser.php">Manage Users</a></li> -->
            <li><a href="cms.php?groupType=Other">Manage Other</a></li>
            <li><a href="feedbacks.php">Manage Feedbacks</a></li>
    	</ul>
  	</li>
</ul>